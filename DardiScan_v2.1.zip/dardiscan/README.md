# DardiScan v1.0
## API Penetration Testing Framework

### Requirements
```bash
pip3 install PyQt5 requests --break-system-packages
```

### Tools Required
- subfinder, nuclei, nmap, ffuf, subzy, shuffledns, alterx, dnsx, naabu, httpx

### Run
```bash
python3 main.py
```

### Features
- Recon: Subfinder, ShuffleDNS, Naabu, Subzy
- API Testing: Endpoint Discovery, CORS, IDOR, JWT, Param Fuzzing
- Vuln Scanner: Nuclei (SQLi, XSS, SSRF, XXE, CORS, SSTI)
- OSINT: crt.sh, DNS, Whois, Shodan, Google Dorking
- Database: SQLite storage + JSON/CSV export
